#include "PlayerItem.h"
#include <QTimer>
#include <QDebug>

PlayerItem::PlayerItem(QObject *parent)
    : QObject(parent), QGraphicsPixmapItem()
{
    m_animationTimer = new QTimer(this);
    connect(m_animationTimer, &QTimer::timeout, [this]() {
        // 行走帧循环：1→2→3→1（跳过站立帧0）
        m_currentWalkFrame = (m_currentWalkFrame % 3) + 1;
        // 显示当前方向+当前行走帧
        showFrame(m_facingDirection, m_currentWalkFrame);
    });
}

// 关键：按4行4列结构解析精灵图
void PlayerItem::setSpriteSheet(const QPixmap &sheet) {
    m_spriteSheet = sheet;

    // 打印精灵图尺寸（调试用）
    qDebug() << "[精灵图] 宽:" << m_spriteSheet.width() << " 高:" << m_spriteSheet.height();

    // 4行4列 → 帧宽=总宽/4，帧高=总高/4
    m_frameWidth = m_spriteSheet.width() / 4;
    m_frameHeight = m_spriteSheet.height() / 4;

    // 打印单帧尺寸（确认是否正确）
    qDebug() << "[单帧尺寸] 宽:" << m_frameWidth << " 高:" << m_frameHeight;

    // 初始显示：向下站立帧（列0=下，行0=站立）
    showFrame(DIR_DOWN, FRAME_STAND);
}

// 核心函数：根据方向（列）和帧（行）裁剪精灵图
void PlayerItem::showFrame(int col, int row) {
    if (m_spriteSheet.isNull() || m_frameWidth == 0 || m_frameHeight == 0) {
        return;
    }

    // 裁剪坐标计算（关键修正：x=列×帧宽，y=行×帧高）
    int x = col * m_frameWidth;  // 列=方向（0-3）→ 控制x坐标
    int y = row * m_frameHeight; // 行=帧（0-3）→ 控制y坐标
    QPixmap targetFrame = m_spriteSheet.copy(x, y, m_frameWidth, m_frameHeight);

    // 裁剪失败兜底（蓝色占位符，便于观察）
    if (targetFrame.isNull()) {
        qWarning() << "[裁剪失败] 方向列:" << col << " 帧行:" << row << " 坐标x:" << x << " y:" << y;
        targetFrame = QPixmap(m_frameWidth, m_frameHeight);
        targetFrame.fill(Qt::blue);
    }

    setPixmap(targetFrame);
}

// 向下走：方向列0，行走帧1-3循环
void PlayerItem::playWalkDown() {
    m_facingDirection = DIR_DOWN;
    m_currentWalkFrame = FRAME_WALK1; // 从行走1帧开始
    showFrame(DIR_DOWN, m_currentWalkFrame);
    m_animationTimer->start(200); // 动画速度（200ms/帧）
}

// 向左走：方向列1，行走帧1-3循环
void PlayerItem::playWalkLeft() {
    m_facingDirection = DIR_LEFT;
    m_currentWalkFrame = FRAME_WALK1;
    showFrame(DIR_LEFT, m_currentWalkFrame);
    m_animationTimer->start(200);
}

// 向右走：方向列2，行走帧1-3循环
void PlayerItem::playWalkRight() {
    m_facingDirection = DIR_RIGHT;
    m_currentWalkFrame = FRAME_WALK1;
    showFrame(DIR_RIGHT, m_currentWalkFrame);
    m_animationTimer->start(200);
}

// 向上走：方向列3，行走帧1-3循环
void PlayerItem::playWalkUp() {
    m_facingDirection = DIR_UP;
    m_currentWalkFrame = FRAME_WALK1;
    showFrame(DIR_UP, m_currentWalkFrame);
    m_animationTimer->start(200);
}

// 停止动画：回到当前方向的站立帧（行0）
void PlayerItem::stopAnimation() {
    m_animationTimer->stop();
    qDebug() << "[停止动画] 当前方向:" << m_facingDirection << "（0=下，1=左，2=右，3=上）";
    showFrame(m_facingDirection, FRAME_STAND); // 行0=站立帧
}

// 物品相关实现（保持不变）
bool PlayerItem::addItemToInventory(const Item &item) {
    bool added = m_inventory.addItem(item);
    if (added) emit inventoryChanged();
    return added;
}

bool PlayerItem::useInventoryItem(int slotIndex) {
    if (slotIndex < 0 || slotIndex >= INVENTORY_SIZE) return false;
    bool used = m_inventory.useItem(slotIndex);
    if (used) emit inventoryChanged();
    return used;
}
