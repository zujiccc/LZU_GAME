#pragma once
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include "Inventory.h"

// 方向=列索引（4列：0=下、1=左、2=右、3=上）
#define DIR_DOWN 0
#define DIR_LEFT 1
#define DIR_RIGHT 2
#define DIR_UP 3

// 帧=行索引（4行：0=站立，1-3=行走1-3帧）
#define FRAME_STAND 0
#define FRAME_WALK1 1
#define FRAME_WALK2 2
#define FRAME_WALK3 3

class PlayerItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
    Q_PROPERTY(QPointF pos READ pos WRITE setPos)

public:
    explicit PlayerItem(QObject *parent = nullptr);

    void setSpriteSheet(const QPixmap &sheet);
    Inventory &inventory() { return m_inventory; }
    const Inventory &inventory() const { return m_inventory; }

    bool addItemToInventory(const Item &item);
    bool useInventoryItem(int slotIndex);

signals:
    void inventoryChanged();

public slots:
    void playWalkDown();
    void playWalkUp();
    void playWalkLeft();
    void playWalkRight();
    void stopAnimation();

private:
    // 核心：col=方向（0-3），row=帧（0=站立，1-3=行走）
    void showFrame(int col, int row);

private:
    Inventory m_inventory;
    QPixmap m_spriteSheet;
    QTimer *m_animationTimer;
    int m_currentWalkFrame = 1; // 行走帧索引（1-3循环，跳过站立帧0）
    int m_facingDirection = DIR_DOWN; // 初始方向=向下（列0）
    int m_frameWidth = 0;   // 单帧宽度（总宽/4）
    int m_frameHeight = 0;  // 单帧高度（总高/4）
};
